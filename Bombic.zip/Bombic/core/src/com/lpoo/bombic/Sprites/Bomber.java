package com.lpoo.bombic.Sprites;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.lpoo.bombic.Bombic;

/**
 * Created by Rui Quaresma on 17/04/2017.
 */

public class Bomber extends Sprite{
    public World world;
    public Body b2body;

    public Bomber(World world){
        this.world = world;
        defineBomber();
    }

    public void defineBomber(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(75, 475);
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody(bdef);

        FixtureDef fdef = new FixtureDef();
        PolygonShape shape = new PolygonShape();
        Vector2[] vertice = new Vector2[4];
        vertice[0] = new Vector2(-30, 20).scl(1 / Bombic.PPM);
        vertice[1] = new Vector2(30, 20).scl(1 / Bombic.PPM);
        vertice[2] = new Vector2(-30, 3).scl(1 / Bombic.PPM);
        vertice[3] = new Vector2(30, 3).scl(1 / Bombic.PPM);
        shape.set(vertice);

        fdef.shape = shape;
        b2body.createFixture(fdef);
    }
}
